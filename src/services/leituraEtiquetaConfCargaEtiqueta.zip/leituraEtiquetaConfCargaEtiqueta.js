$("#codbarra").focus();
$("#mensagemErroG").hide();
$("#mensagemSuccessG").hide();
hideMsgs();

var readBarcode = "";
var etiquetaValida = 0;
var etiquetaInvalida = 0;
var etiquetaDuplicada = 0;
var qtdePalete = 0;
var etqConferidas = 0;
var histLeitura = [];
var etiquetasToConf = [];
var codCarga;
var etiquetaValida;
var totalEtiquetas;
var validaentestoque;
var tatalPedidos;
var qtdeTotalEtiquetas = 0;
var url;
var count = 0;
var requisicoes = [];
var vars = [],
  hash;

var index = 0;

var hashes = window.location.href
  .slice(window.location.href.indexOf("?") + 1)
  .split("&");

for (var i = 0; i < hashes.length; i++) {
  hash = hashes[i].split("=");
  vars.push(hash[0]);
  vars[hash[0]] = hash[1];
}
vars;

codCarga = vars.carga;
etiquetaValida = vars.totconf;
totalEtiquetas = vars.totetiquetas;
qtdeTotalEtiquetas = vars.totetiquetas;
validaentestoque = vars.validarentrada;
tatalPedidos = vars.totaletqpedido;

$("#etiquetasToConf").text(qtdeTotalEtiquetas);
$("#etiquetasValidas").text(etiquetaValida);
$("#codCarga").text(`${codCarga} ${decodeURI(vars.desccarga)}`);
$("#nroPedido").text(vars.pedido);
$("#nomeImp").text(decodeURI(vars.nomeimp));
$("#descEtiqueta").text(decodeURI(vars.descetiq));

url = `${vars.urlApi}rest/pprcleretiquetacargacomimpressaorest`;
urlNode = `${vars.urlNodeService}queue`;
urlFinalizacao = `${vars.urlApi}rest/pprcFinalizaConferenciaRest`;

function hideMsgs() {
  $("#responseDanger").hide();
  $("#responseSuccess").hide();
  $("#responseAlert").hide();
}

function lostInputFocus() {
  var validLostInput = $("#codbarra").val();
  if (validLostInput != "" && validLostInput != null) {
    $("#button").click();
    $("#codbarra").focus();
  }
}

$("#estorna").click(() => {
  $("#codbarra").focus();
});

$("#clearPage").click(function () {
  document.location.reload(true);
});

$(document).keypress(function (e) {
  if (e.which == 13) {
    $("#button").focus();
  }
});

$("#btnZeraPalete").click(() => {
  qtdePalete = 0;
  $("#qtdePalete").text(qtdePalete);
});

$("#finalizaConferencia").click(() => {
  finalizaConferencia();
});

$("button").click(async function (e) {
  hideMsgs();
  readBarcode = $("#codbarra").val().trim();
  let estorna = $("#estorna").is(":checked");
  let jaLida = false;

  if (!estorna) {
    etiquetasToConf.forEach((value) => {
      if (value == readBarcode) {
        jaLida = true;
        return;
      }
    });
  }

  if (readBarcode != "" && !jaLida) {
    if (!estorna) {
      etiquetasToConf.push(readBarcode);
    }

    var parm = new Object();
    parm.CodigoBarras = readBarcode.trim();
    parm.CargaId = vars.carga;
    parm.ModeloEtiquetaId = vars.etiqueta;
    parm.ImpressoraId = vars.imp;
    parm.PedidoId = vars.pedido;
    parm.Estornar = estorna ? 1 : 0;
    parm.isConfEstoque = validaentestoque == "true";
    parm.UsuarioId = vars.user;
    parm.UsuarioLogin = vars.username;
    parm.reqURL = url;

    let json = new Object();
    json.json = parm;

    var requests = [
      {
        url: urlNode,
        method: "POST",
        data: json,
      },
    ];

    console.log("__________________________________");
    console.log("Codigo Barras: " + readBarcode);

    // Chama a função para enviar as solicitações em ordem
    enviarRequisicoesEmOrdem(requests);

    // var worker = new Worker("src/services/leituraEtiquetaWorker.js");

    // worker.onmessage = function (event) {
    //   try {
    //     trataRetorno(JSON.parse(event.data), json);
    //   } catch (e) {
    //     console.log("Error", json["json"]["CodigoBarras"], e);
    //   }
    // };

    // worker.postMessage({ json, urlNode });

    // $.ajax({
    //   url: urlNode,
    //   method: 'POST',
    //   dataType: 'json',
    //   contentType: 'application/json;charset=UTF-8',
    //   data: JSON.stringify(json),
    // })
    //   .done(function (msg) {
    //     console.log('Finalizou requisicao, tratando erros');
    //     trataRetorno(msg, json);
    //   })
    //   .fail(function (jqXHR, textStatus, msg) {
    //     console.log('Error');
    //     histLeitura.push(`<li style="color:red;">${json['json']['CodigoBarras']} Ocorreu um erro inesperado.</li>`);
    //     $('#dangerText').text(msg.Mensagem);
    //     $('#responseDanger').show();
    //   });
  } else {
    $("#alertText").text("Favor, informar um código de etiqueta");
    $("#responseAlert").show();
    if (jaLida) {
      etiquetaDuplicada++;
      $("#etiqeutasDuplicadas").text(etiquetaDuplicada);
      histLeitura.push(
        `<li style="color:red;">${readBarcode} - Leitura duplicada</li>`
      );
    }
  }

  $("#codbarra").val("");
  $("#codbarra").focus();
  $("#historicoLeitura").html(histLeitura);

  if (count >= histLeitura.length) {
    $("#responseAlert").hide();
  }

  if (readBarcode != null) {
    count++;
  }
});

/*
function trataRetorno(msg, json) {
  if (json["json"]["Estornar"] == 1) {
    this.etiquetasToConf.splice(
      this.etiquetasToConf.indexOf(json["json"]["CodigoBarras"]),
      1
    );
  }

  if (msg.MensagemErro == "") {
    this.histLeitura.push(`<li style="color:#041A56;">${msg.Mensagem}</li>`);

    console.log("totalEtiquetas", totalEtiquetas);

    if (json["json"]["Estornar"] == 1) {
      console.log("Estorno");
      etiquetaValida--;
      etqConferidas--;
      qtdePalete--;
      totalEtiquetas = totalEtiquetas + 1;
    } else {
      console.log("Padrão");
      etiquetaValida++;
      etqConferidas++;
      qtdePalete++;
      totalEtiquetas = totalEtiquetas - 1;
    }

    console.log("totalEtiquetas", totalEtiquetas);

    $("#etiquetasToConf").text(totalEtiquetas);
    $("#mensagemErroG").hide();
    $("#mensagemSuccessG").hide();
    $("#qtdePalete").text(qtdePalete);
    $("#etiquetasValidas").text(etiquetaValida);

    //Finaliza a conferência da carga no GNI
    if ((totalEtiquetas = 0)) {
      finalizaConferencia();
    }
  } else {
    this.etiquetasToConf.splice(
      this.etiquetasToConf.indexOf(json["json"]["CodigoBarras"]),
      1
    );
    if (json["json"]["CodigoBarras"] != "")
      this.histLeitura.push(`<li style="color:red;">${msg.MensagemErro}</li>`);
    this.etiquetaInvalida++;
    $("#mensagemErroG").text(
      `${json["json"]["CodigoBarras"]} - ${msg.MensagemErro}`
    );
    $("#mensagemErroG").show();
    $("#etiquetasInvalidas").text(this.etiquetaInvalida);
  }
  if (json["json"]["Estornar"] == 0) {
    this.etiquetasToConf.push(json["json"]["CodigoBarras"]);
  }
  $("#codbarra").focus();
  $("#historicoLeitura").html(this.histLeitura);
}
*/

function finalizaConferencia() {
  $.LoadingOverlay("show", {
    fontawesome: "fas fa-box-check",
    fontawesomeColor: "#273A6E",
  });

  $("#loadingindicator").LoadingOverlay("show");

  var parmFinalizacao = new Object();
  var jsonFinalizacao = new Object();
  parmFinalizacao.CargaId = this.vars.carga;
  parmFinalizacao.NomeConferente = this.vars.username;
  parmFinalizacao.reqURL = this.urlFinalizacao;
  jsonFinalizacao.json = parmFinalizacao;

  $.ajax({
    url: urlNode,
    method: "POST",
    dataType: "json",
    contentType: "application/json;charset=UTF-8",
    data: JSON.stringify(jsonFinalizacao),
    beforeSend: function () {},
  })
    .done(function (msg) {
      if (msg.isError) {
        $("#mensagemErroG").text(`Erro: ${msg.message}`);
        $("#mensagemErroG").show();
      } else {
        $("#mensagemSuccessG").text(`Conferência finalizada com sucesso!`);
        $("#mensagemSuccessG").show();
      }
    })
    .fail(function (jqXHR, textStatus, msg) {
      $("#mensagemErroG").text(
        `Ocorreu um erro ao finalizar a conferência (${msg})`
      );
      $("#mensagemErroG").show();
    });

  $.LoadingOverlay("hide");
  $("#loadingindicator").LoadingOverlay("hide");
}

function enviarRequisicoesEmOrdem(requests) {
  var promises = [];
  requests.forEach(function (request) {
    if (request.data.CodigoBarras != "") promises.push(axios(request));
  });

  return Promise.all(promises)
    .then(function (results) {
      results.forEach(function (result) {
        if (result.data.MensagemErro == "") {
          this.etiquetaValida++;
          this.etqConferidas++;
          this.qtdePalete++;
          this.totalEtiquetas = this.totalEtiquetas - 1;

          $("#etiquetasToConf").text(this.totalEtiquetas);
          $("#mensagemErroG").hide();
          $("#mensagemSuccessG").hide();
          $("#qtdePalete").text(this.qtdePalete);
          $("#etiquetasValidas").text(this.etiquetaValida);

          this.histLeitura.push(
            `<li style="color:#041A56;">${result.data.Mensagem}</li>`
          );

          if (totalEtiquetas == 0) {
            finalizaConferencia();
          }
        } else {
          this.histLeitura.push(
            `<li style="color:red;">${result.data.MensagemErro}</li>`
          );
          this.etiquetaInvalida++;
          $("#etiquetasInvalidas").text(this.etiquetaInvalida);
          $("#mensagemErroG").text(`${result.data.MensagemErro}`);
          $("#mensagemErroG").show();
        }
      });
      $("#historicoLeitura").html(histLeitura);
    })
    .catch(function (error) {
      histLeitura.push(
        `<li style="color:red;"> Ocorreu um erro inesperado. ${JSON.stringify(
          error
        )}</li>`
      );
      $("#historicoLeitura").html(histLeitura);
    });
}
